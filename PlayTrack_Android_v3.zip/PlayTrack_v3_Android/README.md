# PlayTrack v3 Android project

A native Android Studio starter project for PlayTrack (version 2.0, versionCode 3).

## Features
- Home, Games, Stats, Limits, and Settings tabs
- Android UsageStatsManager integration
- User-selected app/game tracking
- Today, last 7 days, last 30 days, and year-to-date totals
- Per-app daily time allowances and in-app limit status
- Simple 7-day usage bars
- Local storage for selected apps and limits
- First-run disclosure explaining Usage Access
- No QUERY_ALL_PACKAGES permission

## Build and run
1. Install Android Studio and Android SDK 35.
2. Open this folder in Android Studio and let Gradle sync.
3. Connect an Android phone or use an emulator, then press Run.
4. In PlayTrack, tap Open Settings under Enable Usage Access, find PlayTrack in Android Settings, and allow Usage Access.
5. Open Games and select the apps to track.

For a signed release, use Android Studio > Build > Generate Signed Bundle / APK. You must create and retain your own signing key.

## Important limitations
- This is an Android project, not an installable APK or an iOS App Store build.
- Usage Access must be granted manually by the device owner.
- Daily limits are informational in this version; it does not force-close or block games.
- Scheduled background notifications are not included in this build.
- Usage totals depend on Android's usage-statistics records and can differ from Digital Wellbeing.
- Before publishing, test on real devices, create a hosted privacy policy, complete Google Play Data safety declarations, and prepare store screenshots and graphics.
