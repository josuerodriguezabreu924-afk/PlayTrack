# PlayTrack Privacy Policy — draft only

Effective date: [DATE] · Developer: [NAME] · Contact: [EMAIL]

PlayTrack requests Android Usage Access to read app-usage statistics and calculate time spent in apps selected by the user. The app stores selected package names and daily-limit settings in local app preferences on the device. In this starter project, usage statistics are not uploaded to a developer server and no advertising or analytics SDKs are included.

Selections and limits remain in local app storage until reset or app uninstall. Android controls retention of underlying usage-history records. Users can revoke Usage Access in Android Settings and reset PlayTrack's saved selections and limits in the app.

Before publishing, replace this draft with a complete policy that reflects the final app, any added SDKs, server-side processing, backup behavior, retention, audience, and applicable legal requirements. Complete Google Play's Data safety section accurately.
