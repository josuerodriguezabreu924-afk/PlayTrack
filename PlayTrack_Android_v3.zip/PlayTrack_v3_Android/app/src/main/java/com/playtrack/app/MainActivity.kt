package com.playtrack.app

import android.app.*
import android.app.usage.UsageStatsManager
import android.app.AppOpsManager
import android.content.*
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import java.util.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("playtrack", MODE_PRIVATE) }
    private var tab = "Home"
    private val purple = Color.rgb(91, 75, 255)
    private val ink = Color.rgb(26, 28, 43)
    private lateinit var page: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!prefs.getBoolean("intro", false)) {
            AlertDialog.Builder(this).setTitle("Welcome to PlayTrack")
                .setMessage("PlayTrack reads Android app-usage statistics to calculate time in games and apps you choose. Your selections and limits are stored on this device in this starter version. It does not read messages, photos, or passwords. You must enable Usage Access in Android Settings.")
                .setPositiveButton("Continue") { _, _ -> prefs.edit().putBoolean("intro", true).apply(); draw() }
                .setCancelable(false).show()
        }
        draw()
    }

    private fun usageAllowed(): Boolean {
        val ops = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        val mode = if (android.os.Build.VERSION.SDK_INT >= 29)
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)
        else @Suppress("DEPRECATION") ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }
    private fun requestAccess() { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
    private fun chosen() = prefs.getStringSet("chosen", emptySet())?.toMutableSet() ?: mutableSetOf()
    private fun limitMap(): MutableMap<String, Int> = (prefs.getString("limits", "") ?: "").split(";")
        .filter { it.contains("=") }.associate { val p=it.split("="); p[0] to (p.getOrNull(1)?.toIntOrNull() ?: 60) }.toMutableMap()
    private fun saveLimits(m: Map<String,Int>) { prefs.edit().putString("limits",m.entries.joinToString(";") { "${it.key}=${it.value}" }).apply() }
    private fun startDay(back: Int = 0): Long = Calendar.getInstance().apply {
        add(Calendar.DAY_OF_YEAR,-back); set(Calendar.HOUR_OF_DAY,0); set(Calendar.MINUTE,0); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0)
    }.timeInMillis
    private fun stats(start: Long, end: Long = System.currentTimeMillis()): Map<String,Long> {
        if (!usageAllowed()) return emptyMap()
        val mgr=getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
        return mgr.queryUsageStats(UsageStatsManager.INTERVAL_DAILY,start,end).groupBy { it.packageName }
            .mapValues { e -> e.value.sumOf { it.totalTimeInForeground } }
    }
    private fun period(days: Int): Map<String,Long> {
        val start = when(days) {
            -1 -> Calendar.getInstance().apply { set(Calendar.DAY_OF_YEAR,1); set(Calendar.HOUR_OF_DAY,0); set(Calendar.MINUTE,0); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0) }.timeInMillis
            30 -> Calendar.getInstance().apply { add(Calendar.MONTH,-1); set(Calendar.HOUR_OF_DAY,0); set(Calendar.MINUTE,0); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0) }.timeInMillis
            else -> startDay(if(days==1) 0 else days-1)
        }
        return stats(start).filterKeys { chosen().contains(it) }
    }
    private fun name(pkg:String):String = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg,0)).toString() } catch(_:Exception){pkg}
    private fun duration(ms:Long):String { val m=ms/60000; return "${m/60}h ${m%60}m" }
    private fun launchable():List<ApplicationInfo> {
        @Suppress("DEPRECATION") val all=packageManager.getInstalledApplications(0)
        return all.filter { packageManager.getLaunchIntentForPackage(it.packageName)!=null && it.packageName!=packageName }
    }
    private fun box(parent:LinearLayout, title:String, detail:String="", action:String?=null, click:(()->Unit)?=null, extra:(LinearLayout.()->Unit)?=null) {
        val c=LinearLayout(this).apply { orientation=1; setPadding(18,16,18,16); setBackgroundColor(Color.WHITE); elevation=2f }
        val lp=LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=12; parent.addView(c,lp)
        c.addView(TextView(this).apply { text=title; textSize=18f; setTextColor(ink); setTypeface(null,1) })
        if(detail.isNotEmpty()) c.addView(TextView(this).apply { text=detail; textSize=14f; setTextColor(Color.DKGRAY); setPadding(0,8,0,8) })
        extra?.invoke(c)
        if(action!=null) c.addView(Button(this).apply { text=action; isAllCaps=false; setOnClickListener { click?.invoke() } })
    }
    private fun draw() {
        val outer=LinearLayout(this).apply { orientation=1; setBackgroundColor(Color.rgb(246,247,251)) }
        val head=LinearLayout(this).apply { orientation=1; setPadding(22,24,22,18); setBackgroundColor(ink) }
        head.addView(TextView(this).apply { text="◉  PlayTrack"; textSize=26f; setTextColor(Color.WHITE); setTypeface(null,1) })
        head.addView(TextView(this).apply { text="Track. Play. Stay balanced."; textSize=13f; setTextColor(Color.LTGRAY) })
        outer.addView(head)
        val scroll=ScrollView(this); page=LinearLayout(this).apply { orientation=1; setPadding(16,18,16,22) }; scroll.addView(page)
        outer.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        val nav=LinearLayout(this).apply { setBackgroundColor(Color.WHITE); gravity=Gravity.CENTER }
        listOf("Home","Games","Stats","Limits","Settings").forEach { t ->
            nav.addView(TextView(this).apply { text=t; gravity=Gravity.CENTER; textSize=11f; setTextColor(if(tab==t) purple else Color.GRAY); setPadding(4,16,4,16); setOnClickListener { tab=t; draw() } },LinearLayout.LayoutParams(0,-2,1f))
        }
        outer.addView(nav); setContentView(outer)
        if(!usageAllowed()) box(page,"Enable Usage Access","Android needs permission to measure time in the apps you select.","Open Settings",{requestAccess()})
        when(tab) { "Home"->home(); "Games"->games(); "Stats"->statistics(); "Limits"->limits(); else->settings() }
    }
    private fun home() {
        val today=period(1); val week=period(7); val selected=chosen()
        box(page,"TODAY'S PLAY TIME",if(usageAllowed()) duration(today.values.sum()) else "—")
        box(page,"Your overview","This week: ${duration(week.values.sum())}\nThis month: ${duration(period(30).values.sum())}\nThis year: ${duration(period(-1).values.sum())}")
        box(page,"Tracked games","${selected.size} apps selected\n"+selected.take(5).joinToString("\n") { "${name(it)} · ${duration(today[it]?:0L)}" },"Manage games",{tab="Games";draw()})
        box(page,"Daily limits","Set a separate daily allowance for each tracked app.","Set limits",{tab="Limits";draw()})
    }
    private fun games() {
        box(page,"Choose apps to track","Select games or apps from your recent usage. Only selected apps count toward PlayTrack totals.")
        if(!usageAllowed()) return
        val recent=stats(startDay(6))
        val apps=launchable().filter { (recent[it.packageName]?:0)>0 }.sortedByDescending { recent[it.packageName]?:0 }
        val set=chosen()
        apps.forEach { info ->
            val pkg=info.packageName
            box(page,name(pkg),"Last 7 days: ${duration(recent[pkg]?:0L)}",extra={
                addView(CheckBox(this@MainActivity).apply {
                    text="Track this app"; isChecked=set.contains(pkg)
                    setOnCheckedChangeListener { _, checked -> val s=chosen(); if(checked)s.add(pkg) else s.remove(pkg); prefs.edit().putStringSet("chosen",s).apply() }
                })
            })
        }
        if(apps.isEmpty()) box(page,"No recent app activity","Use a few apps, then return and refresh.")
        box(page,"Refresh list","", "Refresh",{draw()})
    }
    private fun statistics() {
        box(page,"Statistics","Usage totals for apps you selected.")
        listOf("Today" to 1,"Last 7 days" to 7,"Last 30 days" to 30,"This year" to -1).forEach { (label,n) ->
            val s=period(n)
            box(page,label,duration(s.values.sum())+"\n"+s.entries.sortedByDescending { it.value }.take(5).joinToString("\n") { "${name(it.key)} · ${duration(it.value)}" })
        }
        val lines=(6 downTo 0).joinToString("\n") { d ->
            val m=stats(startDay(d),if(d==0) System.currentTimeMillis() else startDay(d-1)).filterKeys { chosen().contains(it) }.values.sum()/60000
            val day=java.text.SimpleDateFormat("EEE",Locale.getDefault()).format(Date(startDay(d)))
            "$day   ${"▰".repeat((m/30).toInt().coerceIn(0,16))}   ${m}m"
        }
        box(page,"Last 7 days",lines)
    }
    private fun limits() {
        box(page,"Daily game limits","Choose a daily allowance. This version shows warnings inside PlayTrack; it does not block or close other apps.")
        val map=limitMap()
        chosen().forEach { pkg ->
            val current=map[pkg]?:60
            box(page,name(pkg),"Default limit: $current minutes",extra={
                val seek=SeekBar(this@MainActivity).apply { max=360; progress=current.coerceIn(15,360) }
                addView(seek)
                addView(Button(this@MainActivity).apply { text="Save limit"; isAllCaps=false; setOnClickListener {
                    map[pkg]=seek.progress.coerceAtLeast(15); saveLimits(map); Toast.makeText(this@MainActivity,"Limit saved",Toast.LENGTH_SHORT).show(); draw()
                }})
                val used=period(1)[pkg]?:0L
                addView(TextView(this@MainActivity).apply { text=if(used>=current*60000L) "Limit reached · ${duration(used)} used" else "${duration(used)} used today"; setTextColor(if(used>=current*60000L) Color.RED else Color.DKGRAY) })
            })
        }
        if(chosen().isEmpty()) box(page,"No games selected","Select apps in the Games tab first.")
    }
    private fun settings() {
        box(page,"Settings","PlayTrack v2.0 · Android","Refresh usage data",{draw()})
        box(page,"Permissions","Usage Access can be changed any time in Android Settings.","Open Usage Access",{requestAccess()})
        box(page,"Privacy","This starter stores selections and limits locally. Usage stats are read from Android and are not uploaded by this project.")
        box(page,"Reset data","Remove saved app selections and limits.","Reset",{prefs.edit().remove("chosen").remove("limits").apply();draw()})
    }
}
