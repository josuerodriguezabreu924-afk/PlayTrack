plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.playtrack.app"
    compileSdk = 35
    defaultConfig { applicationId = "com.playtrack.app"; minSdk = 26; targetSdk = 35; versionCode = 3; versionName = "2.0" }
}
