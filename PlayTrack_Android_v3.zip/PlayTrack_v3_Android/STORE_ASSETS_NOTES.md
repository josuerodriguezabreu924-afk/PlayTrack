# Store assets checklist
- App icon: 512 × 512 PNG
- Feature graphic: 1024 × 500 PNG
- Phone screenshots captured from the final tested app
Suggested identity: deep navy background, violet accent, circular play/timer symbol, tagline “Track. Play. Stay Balanced.”
