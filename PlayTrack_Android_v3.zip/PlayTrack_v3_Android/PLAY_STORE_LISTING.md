# PlayTrack — Google Play listing draft

**Short description:** Track game time, understand screen time, and set daily limits.

**Full description:**

Take control of your gaming time with PlayTrack. Track the games and apps you choose, review your usage for today, the last 7 days, the last 30 days, and the current year, and set a separate daily time allowance for each app.

Features:
- Track selected games and apps
- Daily, weekly, monthly, and yearly summaries
- See your most-used tracked apps
- Set a daily allowance for each app
- Check usage against each allowance
- Keep selections and limits stored locally on your device

PlayTrack uses Android Usage Access to calculate time spent in apps you choose. You must enable this permission in Android Settings. This version displays limit status inside PlayTrack and does not block or close other apps.

**Tagline:** Track. Play. Stay Balanced.
